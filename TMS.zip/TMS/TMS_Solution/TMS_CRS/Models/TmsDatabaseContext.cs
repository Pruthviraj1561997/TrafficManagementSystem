﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace TMS_CRS.Models;

public partial class TmsDatabaseContext : DbContext
{
    public TmsDatabaseContext()
    {
    }

    public TmsDatabaseContext(DbContextOptions<TmsDatabaseContext> options)
        : base(options)
    {
    }

    public virtual DbSet<OffenceDetail> OffenceDetails { get; set; }

    public virtual DbSet<TmOffence> TmOffences { get; set; }

    public virtual DbSet<TmOwnerdetail> TmOwnerdetails { get; set; }

    public virtual DbSet<TmRegdetail> TmRegdetails { get; set; }

    public virtual DbSet<TmUserMaster> TmUserMasters { get; set; }

    public virtual DbSet<TmVechicleDetail> TmVechicleDetails { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=PRSQL;Initial Catalog=TMS_Database;User ID=labuser;Password=Welcome123$; TrustServerCertificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<OffenceDetail>(entity =>
        {
            entity.HasKey(e => e.OffenceNo).HasName("pk_OffenceNo");

            entity.ToTable("Offence_Details");

            entity.Property(e => e.OffenceNo).HasColumnName("OFFENCE_NO");
            entity.Property(e => e.OffenceId).HasColumnName("OFFENCE_ID");
            entity.Property(e => e.Place)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ReportedBy)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("REPORTED_BY");
            entity.Property(e => e.Status)
                .HasMaxLength(60)
                .IsUnicode(false);
            entity.Property(e => e.Time).HasColumnType("date");
            entity.Property(e => e.VehNo)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("VEH_NO");

            entity.HasOne(d => d.Offence).WithMany(p => p.OffenceDetails)
                .HasForeignKey(d => d.OffenceId)
                .HasConstraintName("fk_offenceID");

            entity.HasOne(d => d.VehNoNavigation).WithMany(p => p.OffenceDetails)
                .HasPrincipalKey(p => p.VehNo)
                .HasForeignKey(d => d.VehNo)
                .HasConstraintName("fk_VehNo");
        });

        modelBuilder.Entity<TmOffence>(entity =>
        {
            entity.HasKey(e => e.OffenceId).HasName("pkOffence_ID");

            entity.ToTable("TM_Offence");

            entity.Property(e => e.OffenceType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.VehType)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TmOwnerdetail>(entity =>
        {
            entity.HasKey(e => e.OwnerId).HasName("pkOwner_ID");

            entity.ToTable("TM_OWNERDETAILS");

            entity.Property(e => e.OwnerId).HasColumnName("Owner_Id");
            entity.Property(e => e.AddProofName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Add_Proof_Name");
            entity.Property(e => e.DateOfBirth).HasColumnType("date");
            entity.Property(e => e.Fname)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("FName");
            entity.Property(e => e.Gender)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.LandLineNo).HasColumnName("LandLine_No");
            entity.Property(e => e.Lname)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("LName");
            entity.Property(e => e.MobileNo).HasColumnName("Mobile_No");
            entity.Property(e => e.Occupation)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PanCardNo)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("PanCard_No");
            entity.Property(e => e.PermAddr)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("PERM_ADDR");
            entity.Property(e => e.TempAddr)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("TEMP_ADDR");
        });

        modelBuilder.Entity<TmRegdetail>(entity =>
        {
            entity.HasKey(e => e.AppNo).HasName("pk_AppNo");

            entity.ToTable("TM_REGDETAILS");

            entity.HasIndex(e => e.VehNo, "UQ__TM_REGDE__77FD7610C6B901B0").IsUnique();

            entity.Property(e => e.AppNo)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("APP_NO");
            entity.Property(e => e.DateOfPurchase)
                .HasColumnType("date")
                .HasColumnName("DATE_OF_PURCHASE");
            entity.Property(e => e.DistrubuterName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("DISTRUBUTER_NAME");
            entity.Property(e => e.OldOwnerId).HasColumnName("OLD_OWNER_ID");
            entity.Property(e => e.OwnerId).HasColumnName("Owner_Id");
            entity.Property(e => e.VehId).HasColumnName("VEH_ID");
            entity.Property(e => e.VehNo)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("VEH_NO");

            entity.HasOne(d => d.OldOwner).WithMany(p => p.TmRegdetailOldOwners)
                .HasForeignKey(d => d.OldOwnerId)
                .HasConstraintName("fk_oldOwnerId");

            entity.HasOne(d => d.Owner).WithMany(p => p.TmRegdetailOwners)
                .HasForeignKey(d => d.OwnerId)
                .HasConstraintName("fk_ownerId");

            entity.HasOne(d => d.Veh).WithMany(p => p.TmRegdetails)
                .HasForeignKey(d => d.VehId)
                .HasConstraintName("fk_vehId");
        });

        modelBuilder.Entity<TmUserMaster>(entity =>
        {
            entity.HasKey(e => e.Username).HasName("pk_username");

            entity.ToTable("TM_UserMaster");

            entity.Property(e => e.Username)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Password)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Rolename)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TmVechicleDetail>(entity =>
        {
            entity.HasKey(e => e.VehId).HasName("pkVeh_ID");

            entity.ToTable("TM_VechicleDetails");

            entity.HasIndex(e => e.EngineNo, "UQ__TM_Vechi__173AC9E3C6DD15D7").IsUnique();

            entity.Property(e => e.VehId).HasColumnName("Veh_Id");
            entity.Property(e => e.CuibicCapacity).HasColumnName("Cuibic_Capacity");
            entity.Property(e => e.DateOfManufacture)
                .HasColumnType("date")
                .HasColumnName("Date_Of_Manufacture");
            entity.Property(e => e.EngineNo)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("ENGINE_NO");
            entity.Property(e => e.FuelUsed)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("Fuel_Used");
            entity.Property(e => e.ManufacturerName)
                .HasMaxLength(60)
                .IsUnicode(false)
                .HasColumnName("MANUFACTURER_NAME");
            entity.Property(e => e.ModelNo)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("MODEL_NO");
            entity.Property(e => e.NoOfCyclinders).HasColumnName("NO_OF_CYCLINDERS");
            entity.Property(e => e.VehColor)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("VEH_COLOR");
            entity.Property(e => e.VehName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("VEH_NAME");
            entity.Property(e => e.VehType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("VEH_TYPE");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
