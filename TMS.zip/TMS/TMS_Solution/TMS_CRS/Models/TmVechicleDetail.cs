﻿using System;
using System.Collections.Generic;

namespace TMS_CRS.Models;

public partial class TmVechicleDetail
{
    public int VehId { get; set; }

    public string VehType { get; set; } = null!;

    public string? EngineNo { get; set; }

    public string ModelNo { get; set; } = null!;

    public string VehName { get; set; } = null!;

    public string? VehColor { get; set; }

    public string ManufacturerName { get; set; } = null!;

    public DateTime DateOfManufacture { get; set; }

    public int? NoOfCyclinders { get; set; }

    public int? CuibicCapacity { get; set; }

    public string? FuelUsed { get; set; }

    public virtual ICollection<TmRegdetail> TmRegdetails { get; } = new List<TmRegdetail>();
}
