﻿using System;
using System.Collections.Generic;

namespace TMS_CRS.Models;

public partial class TmOffence
{
    public int OffenceId { get; set; }

    public string OffenceType { get; set; } = null!;

    public string VehType { get; set; } = null!;

    public int Penalty { get; set; }

    public virtual ICollection<OffenceDetail> OffenceDetails { get; } = new List<OffenceDetail>();
}
