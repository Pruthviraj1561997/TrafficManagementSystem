﻿using System;
using System.Collections.Generic;

namespace TMS_CRS.Models;

public partial class TmUserMaster
{
    public string Username { get; set; } = null!;

    public string Password { get; set; } = null!;

    public string Rolename { get; set; } = null!;
}
