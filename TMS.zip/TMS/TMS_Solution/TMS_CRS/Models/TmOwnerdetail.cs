﻿using System;
using System.Collections.Generic;

namespace TMS_CRS.Models;

public partial class TmOwnerdetail
{
    public int OwnerId { get; set; }

    public string Fname { get; set; } = null!;

    public string Lname { get; set; } = null!;

    public DateTime DateOfBirth { get; set; }

    public long? LandLineNo { get; set; }

    public long? MobileNo { get; set; }

    public string Gender { get; set; } = null!;

    public string? TempAddr { get; set; }

    public string? PermAddr { get; set; }

    public int Pincode { get; set; }

    public string? Occupation { get; set; }

    public string PanCardNo { get; set; } = null!;

    public string AddProofName { get; set; } = null!;

    public virtual ICollection<TmRegdetail> TmRegdetailOldOwners { get; } = new List<TmRegdetail>();

    public virtual ICollection<TmRegdetail> TmRegdetailOwners { get; } = new List<TmRegdetail>();
}
