﻿using System;
using System.Collections.Generic;

namespace TMS_CRS.Models;

public partial class TmRegdetail
{
    public string AppNo { get; set; } = null!;

    public string VehNo { get; set; } = null!;

    public int? VehId { get; set; }

    public int? OwnerId { get; set; }

    public int? OldOwnerId { get; set; }

    public DateTime DateOfPurchase { get; set; }

    public string DistrubuterName { get; set; } = null!;

    public virtual ICollection<OffenceDetail> OffenceDetails { get; } = new List<OffenceDetail>();

    public virtual TmOwnerdetail? OldOwner { get; set; }

    public virtual TmOwnerdetail? Owner { get; set; }

    public virtual TmVechicleDetail? Veh { get; set; }
}
