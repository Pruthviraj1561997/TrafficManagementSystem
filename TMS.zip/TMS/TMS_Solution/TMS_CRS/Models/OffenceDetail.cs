﻿using System;
using System.Collections.Generic;

namespace TMS_CRS.Models;

public partial class OffenceDetail
{
    public int OffenceNo { get; set; }

    public string? VehNo { get; set; }

    public DateTime Time { get; set; }

    public string Place { get; set; } = null!;

    public int? OffenceId { get; set; }

    public string ReportedBy { get; set; } = null!;

    public string Status { get; set; } = null!;

    public virtual TmOffence? Offence { get; set; }

    public virtual TmRegdetail? VehNoNavigation { get; set; }
}
