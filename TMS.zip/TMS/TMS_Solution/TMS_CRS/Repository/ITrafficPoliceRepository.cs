﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TMS_CRS.Models;

namespace TMS_CRS.Repository
{
    public interface ITrafficPoliceRepository
    {
        int Addpenalty(OffenceDetail o);
        bool EditPenalty(OffenceDetail newval, int ono);
        List<OffenceDetail> GenerateReport(string vno);
        List<OffenceDetail> Showalloffence();
        OffenceDetail GetoffencebyOffno(int ono);

        Task<OffenceDetail> DeleteOffenceDeatils(int offenceNo);
    }
}
//Traffic police has three funcationality that is add,edit,Delete and generate report